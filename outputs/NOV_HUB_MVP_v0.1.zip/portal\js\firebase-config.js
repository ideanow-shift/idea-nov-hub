export const PORTAL_CONFIG = {
  // "demo"なら設定不要で動作確認できます。本番公開時は"firebase"へ変更してください。
  authMode: "demo",
  gasApiUrl: "",
  firebase: {
    apiKey: "",
    authDomain: "",
    projectId: "",
    appId: ""
  }
};

export function isFirebaseConfigured() {
  return PORTAL_CONFIG.authMode === "firebase"
    && Object.values(PORTAL_CONFIG.firebase).every(Boolean)
    && Boolean(PORTAL_CONFIG.gasApiUrl);
}
